import 'package:flutter/material.dart';
import './screens/home_screen.dart';
import './screens/welcome_screen.dart';

void main() {
  runApp(MaterialApp(routes: {
    "/": (BuildContext context) => WelcomeScreen(),
    "/home": (BuildContext context) => HomeScreen(),
  }));
}
