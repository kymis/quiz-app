import 'package:flutter/material.dart';

class WelcomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Center(
            child: Column(children: [
      Text('Welcome!'),
      ElevatedButton(
          onPressed: () => Navigator.pushNamed(context, "/home"),
          child: Text("Home"))
    ])));
  }
}
